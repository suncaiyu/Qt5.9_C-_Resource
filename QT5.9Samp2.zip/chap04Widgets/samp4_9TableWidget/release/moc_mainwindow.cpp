/****************************************************************************
** Meta object code from reading C++ file 'mainwindow.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.9.0)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../mainwindow.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'mainwindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.9.0. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_MainWindow_t {
    QByteArrayData data[23];
    char stringdata0[473];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_MainWindow_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_MainWindow_t qt_meta_stringdata_MainWindow = {
    {
QT_MOC_LITERAL(0, 0, 10), // "MainWindow"
QT_MOC_LITERAL(1, 11, 23), // "on_btnSetHeader_clicked"
QT_MOC_LITERAL(2, 35, 0), // ""
QT_MOC_LITERAL(3, 36, 21), // "on_btnSetRows_clicked"
QT_MOC_LITERAL(4, 58, 21), // "on_btnIniData_clicked"
QT_MOC_LITERAL(5, 80, 28), // "on_chkBoxTabEditable_clicked"
QT_MOC_LITERAL(6, 109, 7), // "checked"
QT_MOC_LITERAL(7, 117, 24), // "on_chkBoxHeaderH_clicked"
QT_MOC_LITERAL(8, 142, 24), // "on_chkBoxHeaderV_clicked"
QT_MOC_LITERAL(9, 167, 25), // "on_chkBoxRowColor_clicked"
QT_MOC_LITERAL(10, 193, 25), // "on_rBtnSelectItem_clicked"
QT_MOC_LITERAL(11, 219, 24), // "on_rBtnSelectRow_clicked"
QT_MOC_LITERAL(12, 244, 24), // "on_btnReadToEdit_clicked"
QT_MOC_LITERAL(13, 269, 31), // "on_tableInfo_currentCellChanged"
QT_MOC_LITERAL(14, 301, 10), // "currentRow"
QT_MOC_LITERAL(15, 312, 13), // "currentColumn"
QT_MOC_LITERAL(16, 326, 11), // "previousRow"
QT_MOC_LITERAL(17, 338, 14), // "previousColumn"
QT_MOC_LITERAL(18, 353, 23), // "on_btnInsertRow_clicked"
QT_MOC_LITERAL(19, 377, 23), // "on_btnAppendRow_clicked"
QT_MOC_LITERAL(20, 401, 23), // "on_btnDelCurRow_clicked"
QT_MOC_LITERAL(21, 425, 23), // "on_btnAutoHeght_clicked"
QT_MOC_LITERAL(22, 449, 23) // "on_btnAutoWidth_clicked"

    },
    "MainWindow\0on_btnSetHeader_clicked\0\0"
    "on_btnSetRows_clicked\0on_btnIniData_clicked\0"
    "on_chkBoxTabEditable_clicked\0checked\0"
    "on_chkBoxHeaderH_clicked\0"
    "on_chkBoxHeaderV_clicked\0"
    "on_chkBoxRowColor_clicked\0"
    "on_rBtnSelectItem_clicked\0"
    "on_rBtnSelectRow_clicked\0"
    "on_btnReadToEdit_clicked\0"
    "on_tableInfo_currentCellChanged\0"
    "currentRow\0currentColumn\0previousRow\0"
    "previousColumn\0on_btnInsertRow_clicked\0"
    "on_btnAppendRow_clicked\0on_btnDelCurRow_clicked\0"
    "on_btnAutoHeght_clicked\0on_btnAutoWidth_clicked"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_MainWindow[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      16,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    0,   94,    2, 0x08 /* Private */,
       3,    0,   95,    2, 0x08 /* Private */,
       4,    0,   96,    2, 0x08 /* Private */,
       5,    1,   97,    2, 0x08 /* Private */,
       7,    1,  100,    2, 0x08 /* Private */,
       8,    1,  103,    2, 0x08 /* Private */,
       9,    1,  106,    2, 0x08 /* Private */,
      10,    0,  109,    2, 0x08 /* Private */,
      11,    0,  110,    2, 0x08 /* Private */,
      12,    0,  111,    2, 0x08 /* Private */,
      13,    4,  112,    2, 0x08 /* Private */,
      18,    0,  121,    2, 0x08 /* Private */,
      19,    0,  122,    2, 0x08 /* Private */,
      20,    0,  123,    2, 0x08 /* Private */,
      21,    0,  124,    2, 0x08 /* Private */,
      22,    0,  125,    2, 0x08 /* Private */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool,    6,
    QMetaType::Void, QMetaType::Bool,    6,
    QMetaType::Void, QMetaType::Bool,    6,
    QMetaType::Void, QMetaType::Bool,    6,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int, QMetaType::Int, QMetaType::Int, QMetaType::Int,   14,   15,   16,   17,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void MainWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        MainWindow *_t = static_cast<MainWindow *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->on_btnSetHeader_clicked(); break;
        case 1: _t->on_btnSetRows_clicked(); break;
        case 2: _t->on_btnIniData_clicked(); break;
        case 3: _t->on_chkBoxTabEditable_clicked((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 4: _t->on_chkBoxHeaderH_clicked((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 5: _t->on_chkBoxHeaderV_clicked((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 6: _t->on_chkBoxRowColor_clicked((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 7: _t->on_rBtnSelectItem_clicked(); break;
        case 8: _t->on_rBtnSelectRow_clicked(); break;
        case 9: _t->on_btnReadToEdit_clicked(); break;
        case 10: _t->on_tableInfo_currentCellChanged((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2])),(*reinterpret_cast< int(*)>(_a[3])),(*reinterpret_cast< int(*)>(_a[4]))); break;
        case 11: _t->on_btnInsertRow_clicked(); break;
        case 12: _t->on_btnAppendRow_clicked(); break;
        case 13: _t->on_btnDelCurRow_clicked(); break;
        case 14: _t->on_btnAutoHeght_clicked(); break;
        case 15: _t->on_btnAutoWidth_clicked(); break;
        default: ;
        }
    }
}

const QMetaObject MainWindow::staticMetaObject = {
    { &QMainWindow::staticMetaObject, qt_meta_stringdata_MainWindow.data,
      qt_meta_data_MainWindow,  qt_static_metacall, nullptr, nullptr}
};


const QMetaObject *MainWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MainWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_MainWindow.stringdata0))
        return static_cast<void*>(const_cast< MainWindow*>(this));
    return QMainWindow::qt_metacast(_clname);
}

int MainWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 16)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 16;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 16)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 16;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE

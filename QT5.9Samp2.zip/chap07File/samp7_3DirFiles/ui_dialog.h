/********************************************************************************
** Form generated from reading UI file 'dialog.ui'
**
** Created by: Qt User Interface Compiler version 5.9.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_DIALOG_H
#define UI_DIALOG_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDialog>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPlainTextEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSplitter>
#include <QtWidgets/QToolBox>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Dialog
{
public:
    QVBoxLayout *verticalLayout_10;
    QSplitter *splitter;
    QToolBox *toolBox;
    QWidget *pageApp;
    QVBoxLayout *verticalLayout_3;
    QGroupBox *groupBox_8;
    QVBoxLayout *verticalLayout_2;
    QPushButton *pushButton;
    QPushButton *pushButton_2;
    QPushButton *pushButton_3;
    QPushButton *pushButton_4;
    QPushButton *pushButton_61;
    QPushButton *pushButton_40;
    QWidget *pageFile;
    QVBoxLayout *verticalLayout_8;
    QGroupBox *groupBox_10;
    QGridLayout *gridLayout_7;
    QPushButton *pushButton_50;
    QPushButton *pushButton_51;
    QPushButton *pushButton_48;
    QPushButton *pushButton_49;
    QGroupBox *groupBox_9;
    QGridLayout *gridLayout_5;
    QPushButton *pushButton_53;
    QPushButton *pushButton_54;
    QPushButton *pushButton_55;
    QPushButton *pushButton_56;
    QWidget *pageFileInfo;
    QVBoxLayout *verticalLayout_5;
    QGroupBox *groupBox_6;
    QGridLayout *gridLayout_4;
    QPushButton *pushButton_30;
    QPushButton *pushButton_29;
    QPushButton *pushButton_28;
    QPushButton *pushButton_31;
    QPushButton *pushButton_42;
    QPushButton *pushButton_43;
    QPushButton *pushButton_35;
    QPushButton *pushButton_36;
    QPushButton *pushButton_44;
    QPushButton *pushButton_33;
    QPushButton *pushButton_27;
    QPushButton *pushButton_39;
    QPushButton *pushButton_59;
    QPushButton *pushButton_32;
    QPushButton *pushButton_34;
    QPushButton *pushButton_37;
    QPushButton *pushButton_38;
    QPushButton *pushButton_58;
    QWidget *pageDir;
    QVBoxLayout *verticalLayout_4;
    QGroupBox *groupBox;
    QGridLayout *gridLayout_3;
    QPushButton *pushButton_8;
    QPushButton *pushButton_10;
    QPushButton *pushButton_9;
    QPushButton *pushButton_7;
    QPushButton *pushButton_6;
    QPushButton *pushButton_60;
    QGroupBox *groupBox_4;
    QGridLayout *gridLayout_2;
    QPushButton *pushButton_20;
    QPushButton *pushButton_22;
    QPushButton *pushButton_23;
    QPushButton *pushButton_26;
    QPushButton *pushButton_24;
    QPushButton *pushButton_12;
    QGroupBox *groupBox_3;
    QGridLayout *gridLayout;
    QPushButton *pushButton_14;
    QPushButton *pushButton_15;
    QPushButton *pushButton_19;
    QPushButton *pushButton_16;
    QPushButton *pushButton_18;
    QPushButton *pushButton_13;
    QPushButton *pushButton_17;
    QPushButton *pushButton_11;
    QWidget *pageTemp;
    QHBoxLayout *horizontalLayout_2;
    QGroupBox *groupBox_5;
    QVBoxLayout *verticalLayout_7;
    QPushButton *pushButton_21;
    QPushButton *pushButton_25;
    QWidget *pageWatcher;
    QVBoxLayout *verticalLayout_9;
    QGroupBox *groupBox_11;
    QVBoxLayout *verticalLayout_6;
    QPushButton *pushButton_46;
    QPushButton *pushButton_47;
    QPushButton *pushButton_52;
    QPushButton *pushButton_57;
    QGroupBox *groupBox_2;
    QVBoxLayout *verticalLayout;
    QGroupBox *groupBox_7;
    QHBoxLayout *horizontalLayout;
    QPushButton *pushButton_41;
    QPushButton *pushButton_45;
    QPushButton *pushButton_5;
    QGridLayout *gridLayout_6;
    QLabel *label;
    QLineEdit *editFile;
    QLabel *label_2;
    QLineEdit *editDir;
    QLabel *label_3;
    QPlainTextEdit *plainTextEdit;

    void setupUi(QDialog *Dialog)
    {
        if (Dialog->objectName().isEmpty())
            Dialog->setObjectName(QStringLiteral("Dialog"));
        Dialog->resize(836, 538);
        QFont font;
        font.setPointSize(11);
        Dialog->setFont(font);
        verticalLayout_10 = new QVBoxLayout(Dialog);
        verticalLayout_10->setSpacing(6);
        verticalLayout_10->setContentsMargins(11, 11, 11, 11);
        verticalLayout_10->setObjectName(QStringLiteral("verticalLayout_10"));
        splitter = new QSplitter(Dialog);
        splitter->setObjectName(QStringLiteral("splitter"));
        splitter->setOrientation(Qt::Horizontal);
        toolBox = new QToolBox(splitter);
        toolBox->setObjectName(QStringLiteral("toolBox"));
        toolBox->setMaximumSize(QSize(400, 16777215));
        toolBox->setFrameShape(QFrame::StyledPanel);
        pageApp = new QWidget();
        pageApp->setObjectName(QStringLiteral("pageApp"));
        pageApp->setGeometry(QRect(0, 0, 355, 338));
        verticalLayout_3 = new QVBoxLayout(pageApp);
        verticalLayout_3->setSpacing(6);
        verticalLayout_3->setContentsMargins(11, 11, 11, 11);
        verticalLayout_3->setObjectName(QStringLiteral("verticalLayout_3"));
        groupBox_8 = new QGroupBox(pageApp);
        groupBox_8->setObjectName(QStringLiteral("groupBox_8"));
        verticalLayout_2 = new QVBoxLayout(groupBox_8);
        verticalLayout_2->setSpacing(6);
        verticalLayout_2->setContentsMargins(11, 11, 11, 11);
        verticalLayout_2->setObjectName(QStringLiteral("verticalLayout_2"));
        pushButton = new QPushButton(groupBox_8);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        pushButton->setMinimumSize(QSize(0, 30));

        verticalLayout_2->addWidget(pushButton);

        pushButton_2 = new QPushButton(groupBox_8);
        pushButton_2->setObjectName(QStringLiteral("pushButton_2"));
        pushButton_2->setMinimumSize(QSize(0, 30));

        verticalLayout_2->addWidget(pushButton_2);

        pushButton_3 = new QPushButton(groupBox_8);
        pushButton_3->setObjectName(QStringLiteral("pushButton_3"));
        pushButton_3->setMinimumSize(QSize(0, 30));

        verticalLayout_2->addWidget(pushButton_3);

        pushButton_4 = new QPushButton(groupBox_8);
        pushButton_4->setObjectName(QStringLiteral("pushButton_4"));
        pushButton_4->setMinimumSize(QSize(0, 30));

        verticalLayout_2->addWidget(pushButton_4);

        pushButton_61 = new QPushButton(groupBox_8);
        pushButton_61->setObjectName(QStringLiteral("pushButton_61"));

        verticalLayout_2->addWidget(pushButton_61);

        pushButton_40 = new QPushButton(groupBox_8);
        pushButton_40->setObjectName(QStringLiteral("pushButton_40"));
        pushButton_40->setMinimumSize(QSize(0, 30));

        verticalLayout_2->addWidget(pushButton_40);


        verticalLayout_3->addWidget(groupBox_8);

        QIcon icon;
        icon.addFile(QStringLiteral(":/images/images/802.bmp"), QSize(), QIcon::Normal, QIcon::Off);
        toolBox->addItem(pageApp, icon, QString::fromUtf8("QCoreApplication\347\261\273"));
        pageFile = new QWidget();
        pageFile->setObjectName(QStringLiteral("pageFile"));
        pageFile->setGeometry(QRect(0, 0, 355, 338));
        verticalLayout_8 = new QVBoxLayout(pageFile);
        verticalLayout_8->setSpacing(6);
        verticalLayout_8->setContentsMargins(11, 11, 11, 11);
        verticalLayout_8->setObjectName(QStringLiteral("verticalLayout_8"));
        groupBox_10 = new QGroupBox(pageFile);
        groupBox_10->setObjectName(QStringLiteral("groupBox_10"));
        gridLayout_7 = new QGridLayout(groupBox_10);
        gridLayout_7->setSpacing(6);
        gridLayout_7->setContentsMargins(11, 11, 11, 11);
        gridLayout_7->setObjectName(QStringLiteral("gridLayout_7"));
        pushButton_50 = new QPushButton(groupBox_10);
        pushButton_50->setObjectName(QStringLiteral("pushButton_50"));
        pushButton_50->setMinimumSize(QSize(0, 30));

        gridLayout_7->addWidget(pushButton_50, 1, 1, 1, 1);

        pushButton_51 = new QPushButton(groupBox_10);
        pushButton_51->setObjectName(QStringLiteral("pushButton_51"));
        pushButton_51->setMinimumSize(QSize(0, 30));

        gridLayout_7->addWidget(pushButton_51, 0, 1, 1, 1);

        pushButton_48 = new QPushButton(groupBox_10);
        pushButton_48->setObjectName(QStringLiteral("pushButton_48"));
        pushButton_48->setMinimumSize(QSize(0, 30));

        gridLayout_7->addWidget(pushButton_48, 0, 0, 1, 1);

        pushButton_49 = new QPushButton(groupBox_10);
        pushButton_49->setObjectName(QStringLiteral("pushButton_49"));
        pushButton_49->setMinimumSize(QSize(0, 30));

        gridLayout_7->addWidget(pushButton_49, 1, 0, 1, 1);

        pushButton_48->raise();
        pushButton_49->raise();
        pushButton_50->raise();
        pushButton_51->raise();

        verticalLayout_8->addWidget(groupBox_10);

        groupBox_9 = new QGroupBox(pageFile);
        groupBox_9->setObjectName(QStringLiteral("groupBox_9"));
        gridLayout_5 = new QGridLayout(groupBox_9);
        gridLayout_5->setSpacing(6);
        gridLayout_5->setContentsMargins(11, 11, 11, 11);
        gridLayout_5->setObjectName(QStringLiteral("gridLayout_5"));
        pushButton_53 = new QPushButton(groupBox_9);
        pushButton_53->setObjectName(QStringLiteral("pushButton_53"));
        pushButton_53->setMinimumSize(QSize(0, 30));

        gridLayout_5->addWidget(pushButton_53, 0, 0, 1, 1);

        pushButton_54 = new QPushButton(groupBox_9);
        pushButton_54->setObjectName(QStringLiteral("pushButton_54"));
        pushButton_54->setMinimumSize(QSize(0, 30));

        gridLayout_5->addWidget(pushButton_54, 0, 1, 1, 1);

        pushButton_55 = new QPushButton(groupBox_9);
        pushButton_55->setObjectName(QStringLiteral("pushButton_55"));
        pushButton_55->setMinimumSize(QSize(0, 30));

        gridLayout_5->addWidget(pushButton_55, 2, 0, 1, 1);

        pushButton_56 = new QPushButton(groupBox_9);
        pushButton_56->setObjectName(QStringLiteral("pushButton_56"));
        pushButton_56->setMinimumSize(QSize(0, 30));

        gridLayout_5->addWidget(pushButton_56, 2, 1, 1, 1);


        verticalLayout_8->addWidget(groupBox_9);

        QIcon icon1;
        icon1.addFile(QStringLiteral(":/images/images/804.bmp"), QSize(), QIcon::Normal, QIcon::Off);
        toolBox->addItem(pageFile, icon1, QString::fromUtf8("QFile\347\261\273"));
        pageFileInfo = new QWidget();
        pageFileInfo->setObjectName(QStringLiteral("pageFileInfo"));
        pageFileInfo->setGeometry(QRect(0, 0, 355, 338));
        verticalLayout_5 = new QVBoxLayout(pageFileInfo);
        verticalLayout_5->setSpacing(3);
        verticalLayout_5->setContentsMargins(11, 11, 11, 11);
        verticalLayout_5->setObjectName(QStringLiteral("verticalLayout_5"));
        verticalLayout_5->setContentsMargins(3, 3, 3, 3);
        groupBox_6 = new QGroupBox(pageFileInfo);
        groupBox_6->setObjectName(QStringLiteral("groupBox_6"));
        gridLayout_4 = new QGridLayout(groupBox_6);
        gridLayout_4->setSpacing(3);
        gridLayout_4->setContentsMargins(11, 11, 11, 11);
        gridLayout_4->setObjectName(QStringLiteral("gridLayout_4"));
        gridLayout_4->setContentsMargins(3, 3, 3, 3);
        pushButton_30 = new QPushButton(groupBox_6);
        pushButton_30->setObjectName(QStringLiteral("pushButton_30"));
        pushButton_30->setMinimumSize(QSize(0, 30));

        gridLayout_4->addWidget(pushButton_30, 3, 0, 1, 1);

        pushButton_29 = new QPushButton(groupBox_6);
        pushButton_29->setObjectName(QStringLiteral("pushButton_29"));
        pushButton_29->setMinimumSize(QSize(0, 30));

        gridLayout_4->addWidget(pushButton_29, 0, 1, 1, 1);

        pushButton_28 = new QPushButton(groupBox_6);
        pushButton_28->setObjectName(QStringLiteral("pushButton_28"));
        pushButton_28->setMinimumSize(QSize(0, 30));

        gridLayout_4->addWidget(pushButton_28, 0, 0, 1, 1);

        pushButton_31 = new QPushButton(groupBox_6);
        pushButton_31->setObjectName(QStringLiteral("pushButton_31"));
        pushButton_31->setMinimumSize(QSize(0, 30));

        gridLayout_4->addWidget(pushButton_31, 3, 1, 1, 1);

        pushButton_42 = new QPushButton(groupBox_6);
        pushButton_42->setObjectName(QStringLiteral("pushButton_42"));
        pushButton_42->setMinimumSize(QSize(0, 30));

        gridLayout_4->addWidget(pushButton_42, 6, 0, 1, 1);

        pushButton_43 = new QPushButton(groupBox_6);
        pushButton_43->setObjectName(QStringLiteral("pushButton_43"));
        pushButton_43->setMinimumSize(QSize(0, 30));

        gridLayout_4->addWidget(pushButton_43, 6, 1, 1, 1);

        pushButton_35 = new QPushButton(groupBox_6);
        pushButton_35->setObjectName(QStringLiteral("pushButton_35"));
        pushButton_35->setMinimumSize(QSize(0, 30));

        gridLayout_4->addWidget(pushButton_35, 7, 0, 1, 1);

        pushButton_36 = new QPushButton(groupBox_6);
        pushButton_36->setObjectName(QStringLiteral("pushButton_36"));
        pushButton_36->setMinimumSize(QSize(0, 30));

        gridLayout_4->addWidget(pushButton_36, 8, 0, 1, 1);

        pushButton_44 = new QPushButton(groupBox_6);
        pushButton_44->setObjectName(QStringLiteral("pushButton_44"));
        pushButton_44->setMinimumSize(QSize(0, 30));

        gridLayout_4->addWidget(pushButton_44, 8, 1, 1, 1);

        pushButton_33 = new QPushButton(groupBox_6);
        pushButton_33->setObjectName(QStringLiteral("pushButton_33"));
        pushButton_33->setMinimumSize(QSize(0, 30));

        gridLayout_4->addWidget(pushButton_33, 1, 0, 1, 1);

        pushButton_27 = new QPushButton(groupBox_6);
        pushButton_27->setObjectName(QStringLiteral("pushButton_27"));
        pushButton_27->setMinimumSize(QSize(0, 30));

        gridLayout_4->addWidget(pushButton_27, 10, 1, 1, 1);

        pushButton_39 = new QPushButton(groupBox_6);
        pushButton_39->setObjectName(QStringLiteral("pushButton_39"));
        pushButton_39->setMinimumSize(QSize(0, 30));

        gridLayout_4->addWidget(pushButton_39, 4, 0, 1, 1);

        pushButton_59 = new QPushButton(groupBox_6);
        pushButton_59->setObjectName(QStringLiteral("pushButton_59"));
        pushButton_59->setMinimumSize(QSize(0, 30));

        gridLayout_4->addWidget(pushButton_59, 10, 0, 1, 1);

        pushButton_32 = new QPushButton(groupBox_6);
        pushButton_32->setObjectName(QStringLiteral("pushButton_32"));
        pushButton_32->setMinimumSize(QSize(0, 30));

        gridLayout_4->addWidget(pushButton_32, 4, 1, 1, 1);

        pushButton_34 = new QPushButton(groupBox_6);
        pushButton_34->setObjectName(QStringLiteral("pushButton_34"));
        pushButton_34->setMinimumSize(QSize(0, 30));

        gridLayout_4->addWidget(pushButton_34, 1, 1, 1, 1);

        pushButton_37 = new QPushButton(groupBox_6);
        pushButton_37->setObjectName(QStringLiteral("pushButton_37"));
        pushButton_37->setMinimumSize(QSize(0, 30));

        gridLayout_4->addWidget(pushButton_37, 2, 1, 1, 1);

        pushButton_38 = new QPushButton(groupBox_6);
        pushButton_38->setObjectName(QStringLiteral("pushButton_38"));
        pushButton_38->setMinimumSize(QSize(0, 30));

        gridLayout_4->addWidget(pushButton_38, 2, 0, 1, 1);

        pushButton_58 = new QPushButton(groupBox_6);
        pushButton_58->setObjectName(QStringLiteral("pushButton_58"));
        pushButton_58->setMinimumSize(QSize(0, 30));

        gridLayout_4->addWidget(pushButton_58, 7, 1, 1, 1);


        verticalLayout_5->addWidget(groupBox_6);

        QIcon icon2;
        icon2.addFile(QStringLiteral(":/images/images/135.JPG"), QSize(), QIcon::Normal, QIcon::Off);
        toolBox->addItem(pageFileInfo, icon2, QString::fromUtf8("QFileInfo\347\261\273"));
        pageDir = new QWidget();
        pageDir->setObjectName(QStringLiteral("pageDir"));
        pageDir->setGeometry(QRect(0, 0, 338, 477));
        verticalLayout_4 = new QVBoxLayout(pageDir);
        verticalLayout_4->setSpacing(6);
        verticalLayout_4->setContentsMargins(11, 11, 11, 11);
        verticalLayout_4->setObjectName(QStringLiteral("verticalLayout_4"));
        groupBox = new QGroupBox(pageDir);
        groupBox->setObjectName(QStringLiteral("groupBox"));
        gridLayout_3 = new QGridLayout(groupBox);
        gridLayout_3->setSpacing(6);
        gridLayout_3->setContentsMargins(11, 11, 11, 11);
        gridLayout_3->setObjectName(QStringLiteral("gridLayout_3"));
        pushButton_8 = new QPushButton(groupBox);
        pushButton_8->setObjectName(QStringLiteral("pushButton_8"));
        pushButton_8->setMinimumSize(QSize(0, 30));

        gridLayout_3->addWidget(pushButton_8, 1, 0, 1, 1);

        pushButton_10 = new QPushButton(groupBox);
        pushButton_10->setObjectName(QStringLiteral("pushButton_10"));
        pushButton_10->setMinimumSize(QSize(0, 30));

        gridLayout_3->addWidget(pushButton_10, 0, 0, 1, 1);

        pushButton_9 = new QPushButton(groupBox);
        pushButton_9->setObjectName(QStringLiteral("pushButton_9"));
        pushButton_9->setMinimumSize(QSize(0, 30));

        gridLayout_3->addWidget(pushButton_9, 0, 1, 1, 1);

        pushButton_7 = new QPushButton(groupBox);
        pushButton_7->setObjectName(QStringLiteral("pushButton_7"));
        pushButton_7->setMinimumSize(QSize(0, 30));

        gridLayout_3->addWidget(pushButton_7, 1, 1, 1, 1);

        pushButton_6 = new QPushButton(groupBox);
        pushButton_6->setObjectName(QStringLiteral("pushButton_6"));
        pushButton_6->setMinimumSize(QSize(0, 30));

        gridLayout_3->addWidget(pushButton_6, 2, 0, 1, 1);

        pushButton_60 = new QPushButton(groupBox);
        pushButton_60->setObjectName(QStringLiteral("pushButton_60"));
        pushButton_60->setMinimumSize(QSize(0, 30));

        gridLayout_3->addWidget(pushButton_60, 2, 1, 1, 1);


        verticalLayout_4->addWidget(groupBox);

        groupBox_4 = new QGroupBox(pageDir);
        groupBox_4->setObjectName(QStringLiteral("groupBox_4"));
        gridLayout_2 = new QGridLayout(groupBox_4);
        gridLayout_2->setSpacing(6);
        gridLayout_2->setContentsMargins(11, 11, 11, 11);
        gridLayout_2->setObjectName(QStringLiteral("gridLayout_2"));
        pushButton_20 = new QPushButton(groupBox_4);
        pushButton_20->setObjectName(QStringLiteral("pushButton_20"));
        pushButton_20->setMinimumSize(QSize(0, 30));

        gridLayout_2->addWidget(pushButton_20, 0, 0, 1, 1);

        pushButton_22 = new QPushButton(groupBox_4);
        pushButton_22->setObjectName(QStringLiteral("pushButton_22"));
        pushButton_22->setMinimumSize(QSize(0, 30));

        gridLayout_2->addWidget(pushButton_22, 2, 0, 1, 1);

        pushButton_23 = new QPushButton(groupBox_4);
        pushButton_23->setObjectName(QStringLiteral("pushButton_23"));
        pushButton_23->setMinimumSize(QSize(0, 30));

        gridLayout_2->addWidget(pushButton_23, 2, 1, 1, 1);

        pushButton_26 = new QPushButton(groupBox_4);
        pushButton_26->setObjectName(QStringLiteral("pushButton_26"));
        pushButton_26->setMinimumSize(QSize(0, 30));

        gridLayout_2->addWidget(pushButton_26, 3, 0, 1, 1);

        pushButton_24 = new QPushButton(groupBox_4);
        pushButton_24->setObjectName(QStringLiteral("pushButton_24"));
        pushButton_24->setMinimumSize(QSize(0, 30));

        gridLayout_2->addWidget(pushButton_24, 0, 1, 1, 1);

        pushButton_12 = new QPushButton(groupBox_4);
        pushButton_12->setObjectName(QStringLiteral("pushButton_12"));
        pushButton_12->setMinimumSize(QSize(0, 30));

        gridLayout_2->addWidget(pushButton_12, 3, 1, 1, 1);


        verticalLayout_4->addWidget(groupBox_4);

        groupBox_3 = new QGroupBox(pageDir);
        groupBox_3->setObjectName(QStringLiteral("groupBox_3"));
        gridLayout = new QGridLayout(groupBox_3);
        gridLayout->setSpacing(6);
        gridLayout->setContentsMargins(11, 11, 11, 11);
        gridLayout->setObjectName(QStringLiteral("gridLayout"));
        pushButton_14 = new QPushButton(groupBox_3);
        pushButton_14->setObjectName(QStringLiteral("pushButton_14"));
        pushButton_14->setMinimumSize(QSize(0, 30));

        gridLayout->addWidget(pushButton_14, 0, 1, 1, 1);

        pushButton_15 = new QPushButton(groupBox_3);
        pushButton_15->setObjectName(QStringLiteral("pushButton_15"));
        pushButton_15->setMinimumSize(QSize(0, 30));

        gridLayout->addWidget(pushButton_15, 1, 0, 1, 1);

        pushButton_19 = new QPushButton(groupBox_3);
        pushButton_19->setObjectName(QStringLiteral("pushButton_19"));
        pushButton_19->setMinimumSize(QSize(0, 30));

        gridLayout->addWidget(pushButton_19, 1, 1, 1, 1);

        pushButton_16 = new QPushButton(groupBox_3);
        pushButton_16->setObjectName(QStringLiteral("pushButton_16"));
        pushButton_16->setMinimumSize(QSize(0, 30));

        gridLayout->addWidget(pushButton_16, 2, 1, 1, 1);

        pushButton_18 = new QPushButton(groupBox_3);
        pushButton_18->setObjectName(QStringLiteral("pushButton_18"));
        pushButton_18->setMinimumSize(QSize(0, 30));

        gridLayout->addWidget(pushButton_18, 2, 0, 1, 1);

        pushButton_13 = new QPushButton(groupBox_3);
        pushButton_13->setObjectName(QStringLiteral("pushButton_13"));
        pushButton_13->setMinimumSize(QSize(0, 30));

        gridLayout->addWidget(pushButton_13, 0, 0, 1, 1);

        pushButton_17 = new QPushButton(groupBox_3);
        pushButton_17->setObjectName(QStringLiteral("pushButton_17"));
        pushButton_17->setMinimumSize(QSize(0, 30));

        gridLayout->addWidget(pushButton_17, 3, 1, 1, 1);

        pushButton_11 = new QPushButton(groupBox_3);
        pushButton_11->setObjectName(QStringLiteral("pushButton_11"));
        pushButton_11->setMinimumSize(QSize(0, 30));

        gridLayout->addWidget(pushButton_11, 3, 0, 1, 1);


        verticalLayout_4->addWidget(groupBox_3);

        QIcon icon3;
        icon3.addFile(QStringLiteral(":/images/images/007.GIF"), QSize(), QIcon::Normal, QIcon::Off);
        toolBox->addItem(pageDir, icon3, QString::fromUtf8("QDir\347\261\273"));
        pageTemp = new QWidget();
        pageTemp->setObjectName(QStringLiteral("pageTemp"));
        pageTemp->setGeometry(QRect(0, 0, 355, 338));
        horizontalLayout_2 = new QHBoxLayout(pageTemp);
        horizontalLayout_2->setSpacing(6);
        horizontalLayout_2->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_2->setObjectName(QStringLiteral("horizontalLayout_2"));
        groupBox_5 = new QGroupBox(pageTemp);
        groupBox_5->setObjectName(QStringLiteral("groupBox_5"));
        verticalLayout_7 = new QVBoxLayout(groupBox_5);
        verticalLayout_7->setSpacing(6);
        verticalLayout_7->setContentsMargins(11, 11, 11, 11);
        verticalLayout_7->setObjectName(QStringLiteral("verticalLayout_7"));
        pushButton_21 = new QPushButton(groupBox_5);
        pushButton_21->setObjectName(QStringLiteral("pushButton_21"));
        pushButton_21->setMinimumSize(QSize(0, 30));

        verticalLayout_7->addWidget(pushButton_21);

        pushButton_25 = new QPushButton(groupBox_5);
        pushButton_25->setObjectName(QStringLiteral("pushButton_25"));
        pushButton_25->setMinimumSize(QSize(0, 30));

        verticalLayout_7->addWidget(pushButton_25);


        horizontalLayout_2->addWidget(groupBox_5);

        QIcon icon4;
        icon4.addFile(QStringLiteral(":/images/images/806.bmp"), QSize(), QIcon::Normal, QIcon::Off);
        toolBox->addItem(pageTemp, icon4, QString::fromUtf8("QTemporaryDir\345\222\214QTemporaryFile"));
        pageWatcher = new QWidget();
        pageWatcher->setObjectName(QStringLiteral("pageWatcher"));
        pageWatcher->setGeometry(QRect(0, 0, 355, 338));
        verticalLayout_9 = new QVBoxLayout(pageWatcher);
        verticalLayout_9->setSpacing(6);
        verticalLayout_9->setContentsMargins(11, 11, 11, 11);
        verticalLayout_9->setObjectName(QStringLiteral("verticalLayout_9"));
        groupBox_11 = new QGroupBox(pageWatcher);
        groupBox_11->setObjectName(QStringLiteral("groupBox_11"));
        verticalLayout_6 = new QVBoxLayout(groupBox_11);
        verticalLayout_6->setSpacing(6);
        verticalLayout_6->setContentsMargins(11, 11, 11, 11);
        verticalLayout_6->setObjectName(QStringLiteral("verticalLayout_6"));
        pushButton_46 = new QPushButton(groupBox_11);
        pushButton_46->setObjectName(QStringLiteral("pushButton_46"));
        pushButton_46->setMinimumSize(QSize(0, 30));

        verticalLayout_6->addWidget(pushButton_46);

        pushButton_47 = new QPushButton(groupBox_11);
        pushButton_47->setObjectName(QStringLiteral("pushButton_47"));
        pushButton_47->setMinimumSize(QSize(0, 30));

        verticalLayout_6->addWidget(pushButton_47);

        pushButton_52 = new QPushButton(groupBox_11);
        pushButton_52->setObjectName(QStringLiteral("pushButton_52"));
        pushButton_52->setMinimumSize(QSize(0, 30));

        verticalLayout_6->addWidget(pushButton_52);

        pushButton_57 = new QPushButton(groupBox_11);
        pushButton_57->setObjectName(QStringLiteral("pushButton_57"));
        pushButton_57->setMinimumSize(QSize(0, 30));

        verticalLayout_6->addWidget(pushButton_57);


        verticalLayout_9->addWidget(groupBox_11);

        QIcon icon5;
        icon5.addFile(QStringLiteral(":/images/images/714.bmp"), QSize(), QIcon::Normal, QIcon::Off);
        toolBox->addItem(pageWatcher, icon5, QString::fromUtf8("QFileSystemWatcher\347\261\273"));
        splitter->addWidget(toolBox);
        groupBox_2 = new QGroupBox(splitter);
        groupBox_2->setObjectName(QStringLiteral("groupBox_2"));
        groupBox_2->setFlat(false);
        verticalLayout = new QVBoxLayout(groupBox_2);
        verticalLayout->setSpacing(6);
        verticalLayout->setContentsMargins(11, 11, 11, 11);
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        groupBox_7 = new QGroupBox(groupBox_2);
        groupBox_7->setObjectName(QStringLiteral("groupBox_7"));
        horizontalLayout = new QHBoxLayout(groupBox_7);
        horizontalLayout->setSpacing(6);
        horizontalLayout->setContentsMargins(11, 11, 11, 11);
        horizontalLayout->setObjectName(QStringLiteral("horizontalLayout"));
        pushButton_41 = new QPushButton(groupBox_7);
        pushButton_41->setObjectName(QStringLiteral("pushButton_41"));
        pushButton_41->setMinimumSize(QSize(0, 30));
        pushButton_41->setIcon(icon3);

        horizontalLayout->addWidget(pushButton_41);

        pushButton_45 = new QPushButton(groupBox_7);
        pushButton_45->setObjectName(QStringLiteral("pushButton_45"));
        pushButton_45->setMinimumSize(QSize(0, 30));
        QIcon icon6;
        icon6.addFile(QStringLiteral(":/images/images/122.bmp"), QSize(), QIcon::Normal, QIcon::Off);
        pushButton_45->setIcon(icon6);

        horizontalLayout->addWidget(pushButton_45);

        pushButton_5 = new QPushButton(groupBox_7);
        pushButton_5->setObjectName(QStringLiteral("pushButton_5"));
        pushButton_5->setMinimumSize(QSize(0, 30));
        QIcon icon7;
        icon7.addFile(QStringLiteral(":/images/images/212.bmp"), QSize(), QIcon::Normal, QIcon::Off);
        pushButton_5->setIcon(icon7);

        horizontalLayout->addWidget(pushButton_5);


        verticalLayout->addWidget(groupBox_7);

        gridLayout_6 = new QGridLayout();
        gridLayout_6->setSpacing(6);
        gridLayout_6->setObjectName(QStringLiteral("gridLayout_6"));
        label = new QLabel(groupBox_2);
        label->setObjectName(QStringLiteral("label"));

        gridLayout_6->addWidget(label, 0, 0, 1, 1);

        editFile = new QLineEdit(groupBox_2);
        editFile->setObjectName(QStringLiteral("editFile"));
        editFile->setClearButtonEnabled(true);

        gridLayout_6->addWidget(editFile, 0, 1, 1, 1);

        label_2 = new QLabel(groupBox_2);
        label_2->setObjectName(QStringLiteral("label_2"));

        gridLayout_6->addWidget(label_2, 1, 0, 1, 1);

        editDir = new QLineEdit(groupBox_2);
        editDir->setObjectName(QStringLiteral("editDir"));
        editDir->setClearButtonEnabled(true);

        gridLayout_6->addWidget(editDir, 1, 1, 1, 1);

        label_3 = new QLabel(groupBox_2);
        label_3->setObjectName(QStringLiteral("label_3"));

        gridLayout_6->addWidget(label_3, 2, 0, 1, 1);

        plainTextEdit = new QPlainTextEdit(groupBox_2);
        plainTextEdit->setObjectName(QStringLiteral("plainTextEdit"));
        QFont font1;
        font1.setPointSize(12);
        plainTextEdit->setFont(font1);
        plainTextEdit->setLineWrapMode(QPlainTextEdit::WidgetWidth);

        gridLayout_6->addWidget(plainTextEdit, 2, 1, 1, 1);


        verticalLayout->addLayout(gridLayout_6);

        splitter->addWidget(groupBox_2);

        verticalLayout_10->addWidget(splitter);


        retranslateUi(Dialog);

        toolBox->setCurrentIndex(2);


        QMetaObject::connectSlotsByName(Dialog);
    } // setupUi

    void retranslateUi(QDialog *Dialog)
    {
        Dialog->setWindowTitle(QApplication::translate("Dialog", "\347\233\256\345\275\225\345\222\214\346\226\207\344\273\266\346\223\215\344\275\234", Q_NULLPTR));
        groupBox_8->setTitle(QString());
#ifndef QT_NO_TOOLTIP
        pushButton->setToolTip(QApplication::translate("Dialog", "Returns the directory that contains the application executable", Q_NULLPTR));
#endif // QT_NO_TOOLTIP
        pushButton->setText(QApplication::translate("Dialog", "applicationDirPath()", Q_NULLPTR));
#ifndef QT_NO_TOOLTIP
        pushButton_2->setToolTip(QApplication::translate("Dialog", "Returns the file path of the application executable", Q_NULLPTR));
#endif // QT_NO_TOOLTIP
        pushButton_2->setText(QApplication::translate("Dialog", "applicationFilePath()", Q_NULLPTR));
#ifndef QT_NO_TOOLTIP
        pushButton_3->setToolTip(QApplication::translate("Dialog", "This property holds the name of this application", Q_NULLPTR));
#endif // QT_NO_TOOLTIP
        pushButton_3->setText(QApplication::translate("Dialog", "applicationName()", Q_NULLPTR));
#ifndef QT_NO_TOOLTIP
        pushButton_4->setToolTip(QApplication::translate("Dialog", "Returns a list of paths that the application will search when dynamically loading libraries", Q_NULLPTR));
#endif // QT_NO_TOOLTIP
        pushButton_4->setText(QApplication::translate("Dialog", "libraryPaths()", Q_NULLPTR));
#ifndef QT_NO_TOOLTIP
        pushButton_61->setToolTip(QApplication::translate("Dialog", "This property holds the name of the organization that wrote this application", Q_NULLPTR));
#endif // QT_NO_TOOLTIP
        pushButton_61->setText(QApplication::translate("Dialog", "organizationName()", Q_NULLPTR));
#ifndef QT_NO_TOOLTIP
        pushButton_40->setToolTip(QApplication::translate("Dialog", "Enters the main event loop and waits until exit() is called", Q_NULLPTR));
#endif // QT_NO_TOOLTIP
        pushButton_40->setText(QApplication::translate("Dialog", "exit() \351\200\200\345\207\272\345\272\224\347\224\250\347\250\213\345\272\217", Q_NULLPTR));
        toolBox->setItemText(toolBox->indexOf(pageApp), QApplication::translate("Dialog", "QCoreApplication\347\261\273", Q_NULLPTR));
        groupBox_10->setTitle(QApplication::translate("Dialog", "\351\235\231\346\200\201\345\207\275\346\225\260", Q_NULLPTR));
#ifndef QT_NO_TOOLTIP
        pushButton_50->setToolTip(QApplication::translate("Dialog", "Renames the file oldName to newName. ", Q_NULLPTR));
#endif // QT_NO_TOOLTIP
        pushButton_50->setText(QApplication::translate("Dialog", "rename()", Q_NULLPTR));
#ifndef QT_NO_TOOLTIP
        pushButton_51->setToolTip(QApplication::translate("Dialog", "Returns true if the file specified by fileName exists; otherwise returns false.", Q_NULLPTR));
#endif // QT_NO_TOOLTIP
        pushButton_51->setText(QApplication::translate("Dialog", "exists()", Q_NULLPTR));
#ifndef QT_NO_TOOLTIP
        pushButton_48->setToolTip(QApplication::translate("Dialog", "Copies the file fileName to newName.", Q_NULLPTR));
#endif // QT_NO_TOOLTIP
        pushButton_48->setText(QApplication::translate("Dialog", "copy()", Q_NULLPTR));
#ifndef QT_NO_TOOLTIP
        pushButton_49->setToolTip(QApplication::translate("Dialog", "Removes the file specified by the fileName given.", Q_NULLPTR));
#endif // QT_NO_TOOLTIP
        pushButton_49->setText(QApplication::translate("Dialog", "remove()", Q_NULLPTR));
        groupBox_9->setTitle(QApplication::translate("Dialog", "\346\210\220\345\221\230\345\207\275\346\225\260", Q_NULLPTR));
#ifndef QT_NO_TOOLTIP
        pushButton_53->setToolTip(QApplication::translate("Dialog", "Copies the file currently specified by fileName() to a file called newName", Q_NULLPTR));
#endif // QT_NO_TOOLTIP
        pushButton_53->setText(QApplication::translate("Dialog", "copy()", Q_NULLPTR));
#ifndef QT_NO_TOOLTIP
        pushButton_54->setToolTip(QApplication::translate("Dialog", "Returns true if the file specified by fileName() exists; otherwise returns false.", Q_NULLPTR));
#endif // QT_NO_TOOLTIP
        pushButton_54->setText(QApplication::translate("Dialog", "exists()", Q_NULLPTR));
#ifndef QT_NO_TOOLTIP
        pushButton_55->setToolTip(QApplication::translate("Dialog", "Removes the file specified by fileName(). Returns true if successful; otherwise returns false.", Q_NULLPTR));
#endif // QT_NO_TOOLTIP
        pushButton_55->setText(QApplication::translate("Dialog", "remove()", Q_NULLPTR));
#ifndef QT_NO_TOOLTIP
        pushButton_56->setToolTip(QApplication::translate("Dialog", "Renames the file currently specified by fileName() to newName. Returns true if successful; otherwise returns false.", Q_NULLPTR));
#endif // QT_NO_TOOLTIP
        pushButton_56->setText(QApplication::translate("Dialog", "rename()", Q_NULLPTR));
        toolBox->setItemText(toolBox->indexOf(pageFile), QApplication::translate("Dialog", "QFile\347\261\273", Q_NULLPTR));
        groupBox_6->setTitle(QApplication::translate("Dialog", "\346\226\207\344\273\266\344\277\241\346\201\257", Q_NULLPTR));
#ifndef QT_NO_TOOLTIP
        pushButton_30->setToolTip(QApplication::translate("Dialog", "The base name consists of all characters in the file up to (but not including) the first '.' character", Q_NULLPTR));
#endif // QT_NO_TOOLTIP
        pushButton_30->setText(QApplication::translate("Dialog", "baseName()", Q_NULLPTR));
#ifndef QT_NO_TOOLTIP
        pushButton_29->setToolTip(QApplication::translate("Dialog", "Returns a file's path absolute path. This doesn't include the file name", Q_NULLPTR));
#endif // QT_NO_TOOLTIP
        pushButton_29->setText(QApplication::translate("Dialog", "absolutePath() ", Q_NULLPTR));
#ifndef QT_NO_TOOLTIP
        pushButton_28->setToolTip(QApplication::translate("Dialog", "Returns an absolute path including the file name", Q_NULLPTR));
#endif // QT_NO_TOOLTIP
        pushButton_28->setText(QApplication::translate("Dialog", "absoluteFilePath()", Q_NULLPTR));
#ifndef QT_NO_TOOLTIP
        pushButton_31->setToolTip(QApplication::translate("Dialog", "The complete base name consists of all characters in the file up to (but not including) the last '.' character", Q_NULLPTR));
#endif // QT_NO_TOOLTIP
        pushButton_31->setText(QApplication::translate("Dialog", "completeBaseName()", Q_NULLPTR));
#ifndef QT_NO_TOOLTIP
        pushButton_42->setToolTip(QApplication::translate("Dialog", "Returns true if this object points to a directory or to a symbolic link to a directory; otherwise returns false", Q_NULLPTR));
#endif // QT_NO_TOOLTIP
        pushButton_42->setText(QApplication::translate("Dialog", "isDir()", Q_NULLPTR));
#ifndef QT_NO_TOOLTIP
        pushButton_43->setToolTip(QApplication::translate("Dialog", "Returns true if this object points to a file or to a symbolic link to a file", Q_NULLPTR));
#endif // QT_NO_TOOLTIP
        pushButton_43->setText(QApplication::translate("Dialog", "isFile()", Q_NULLPTR));
#ifndef QT_NO_TOOLTIP
        pushButton_35->setToolTip(QApplication::translate("Dialog", "Returns true if the file is executable; otherwise returns false.", Q_NULLPTR));
#endif // QT_NO_TOOLTIP
        pushButton_35->setText(QApplication::translate("Dialog", "isExecutable()", Q_NULLPTR));
#ifndef QT_NO_TOOLTIP
        pushButton_36->setToolTip(QApplication::translate("Dialog", "Returns the date and time when the file was last modified.", Q_NULLPTR));
#endif // QT_NO_TOOLTIP
        pushButton_36->setText(QApplication::translate("Dialog", "lastModified()", Q_NULLPTR));
#ifndef QT_NO_TOOLTIP
        pushButton_44->setToolTip(QApplication::translate("Dialog", "Returns the date and time when the file was last read (accessed).", Q_NULLPTR));
#endif // QT_NO_TOOLTIP
        pushButton_44->setText(QApplication::translate("Dialog", "lastRead()", Q_NULLPTR));
#ifndef QT_NO_TOOLTIP
        pushButton_33->setToolTip(QApplication::translate("Dialog", "Returns the name of the file, excluding the path.", Q_NULLPTR));
#endif // QT_NO_TOOLTIP
        pushButton_33->setText(QApplication::translate("Dialog", "fileName()", Q_NULLPTR));
#ifndef QT_NO_TOOLTIP
        pushButton_27->setToolTip(QApplication::translate("Dialog", "Returns true if the file exists; otherwise returns false", Q_NULLPTR));
#endif // QT_NO_TOOLTIP
        pushButton_27->setText(QApplication::translate("Dialog", "exists()", Q_NULLPTR));
#ifndef QT_NO_TOOLTIP
        pushButton_39->setToolTip(QApplication::translate("Dialog", "The suffix consists of all characters in the file after (but not including) the last '.'", Q_NULLPTR));
#endif // QT_NO_TOOLTIP
        pushButton_39->setText(QApplication::translate("Dialog", "suffix()", Q_NULLPTR));
#ifndef QT_NO_TOOLTIP
        pushButton_59->setToolTip(QApplication::translate("Dialog", "Returns true if the file exists; otherwise returns false", Q_NULLPTR));
#endif // QT_NO_TOOLTIP
        pushButton_59->setText(QApplication::translate("Dialog", "\351\235\231\346\200\201\345\207\275\346\225\260exists()", Q_NULLPTR));
#ifndef QT_NO_TOOLTIP
        pushButton_32->setToolTip(QApplication::translate("Dialog", "The complete suffix consists of all characters in the file after (but not including) the first '.'", Q_NULLPTR));
#endif // QT_NO_TOOLTIP
        pushButton_32->setText(QApplication::translate("Dialog", "completeSuffix()", Q_NULLPTR));
#ifndef QT_NO_TOOLTIP
        pushButton_34->setToolTip(QApplication::translate("Dialog", "Returns the file name, including the path (which may be absolute or relative).", Q_NULLPTR));
#endif // QT_NO_TOOLTIP
        pushButton_34->setText(QApplication::translate("Dialog", "filePath()", Q_NULLPTR));
#ifndef QT_NO_TOOLTIP
        pushButton_37->setToolTip(QApplication::translate("Dialog", "Returns the file's path. This doesn't include the file name.", Q_NULLPTR));
#endif // QT_NO_TOOLTIP
        pushButton_37->setText(QApplication::translate("Dialog", "path()", Q_NULLPTR));
#ifndef QT_NO_TOOLTIP
        pushButton_38->setToolTip(QApplication::translate("Dialog", "Returns the file size in bytes.", Q_NULLPTR));
#endif // QT_NO_TOOLTIP
        pushButton_38->setText(QApplication::translate("Dialog", "size()", Q_NULLPTR));
#ifndef QT_NO_TOOLTIP
        pushButton_58->setToolTip(QApplication::translate("Dialog", "Returns the date and time when the file was created.", Q_NULLPTR));
#endif // QT_NO_TOOLTIP
        pushButton_58->setText(QApplication::translate("Dialog", "created()", Q_NULLPTR));
        toolBox->setItemText(toolBox->indexOf(pageFileInfo), QApplication::translate("Dialog", "QFileInfo\347\261\273", Q_NULLPTR));
        groupBox->setTitle(QApplication::translate("Dialog", "\351\235\231\346\200\201\345\207\275\346\225\260", Q_NULLPTR));
#ifndef QT_NO_TOOLTIP
        pushButton_8->setToolTip(QApplication::translate("Dialog", "Returns the absolute path of the user's home directory", Q_NULLPTR));
#endif // QT_NO_TOOLTIP
        pushButton_8->setText(QApplication::translate("Dialog", "homePath()", Q_NULLPTR));
#ifndef QT_NO_TOOLTIP
        pushButton_10->setToolTip(QApplication::translate("Dialog", "Returns the absolute path of the system's temporary directory", Q_NULLPTR));
#endif // QT_NO_TOOLTIP
        pushButton_10->setText(QApplication::translate("Dialog", "tempPath()", Q_NULLPTR));
#ifndef QT_NO_TOOLTIP
        pushButton_9->setToolTip(QApplication::translate("Dialog", "Returns the absolute path of the root directory", Q_NULLPTR));
#endif // QT_NO_TOOLTIP
        pushButton_9->setText(QApplication::translate("Dialog", "rootPath()", Q_NULLPTR));
#ifndef QT_NO_TOOLTIP
        pushButton_7->setToolTip(QApplication::translate("Dialog", "Returns a list of the root directories on this system", Q_NULLPTR));
#endif // QT_NO_TOOLTIP
        pushButton_7->setText(QApplication::translate("Dialog", "drives()", Q_NULLPTR));
#ifndef QT_NO_TOOLTIP
        pushButton_6->setToolTip(QApplication::translate("Dialog", "Returns the absolute path of the application's current directory", Q_NULLPTR));
#endif // QT_NO_TOOLTIP
        pushButton_6->setText(QApplication::translate("Dialog", "currentPath()", Q_NULLPTR));
#ifndef QT_NO_TOOLTIP
        pushButton_60->setToolTip(QApplication::translate("Dialog", "Sets the application's current working directory to path", Q_NULLPTR));
#endif // QT_NO_TOOLTIP
        pushButton_60->setText(QApplication::translate("Dialog", "setCurrent()", Q_NULLPTR));
        groupBox_4->setTitle(QApplication::translate("Dialog", "\346\226\207\344\273\266\346\210\226\347\233\256\345\275\225\346\223\215\344\275\234", Q_NULLPTR));
#ifndef QT_NO_TOOLTIP
        pushButton_20->setToolTip(QApplication::translate("Dialog", "Creates a sub-directory called dirName.", Q_NULLPTR));
#endif // QT_NO_TOOLTIP
        pushButton_20->setText(QApplication::translate("Dialog", "mkdir()", Q_NULLPTR));
#ifndef QT_NO_TOOLTIP
        pushButton_22->setToolTip(QApplication::translate("Dialog", "Removes the file, fileName.", Q_NULLPTR));
#endif // QT_NO_TOOLTIP
        pushButton_22->setText(QApplication::translate("Dialog", "remove()", Q_NULLPTR));
#ifndef QT_NO_TOOLTIP
        pushButton_23->setToolTip(QApplication::translate("Dialog", "Renames a file or directory from oldName to newName", Q_NULLPTR));
#endif // QT_NO_TOOLTIP
        pushButton_23->setText(QApplication::translate("Dialog", "rename()", Q_NULLPTR));
#ifndef QT_NO_TOOLTIP
        pushButton_26->setToolTip(QApplication::translate("Dialog", "Sets the path of the directory to path", Q_NULLPTR));
#endif // QT_NO_TOOLTIP
        pushButton_26->setText(QApplication::translate("Dialog", "setPath()", Q_NULLPTR));
#ifndef QT_NO_TOOLTIP
        pushButton_24->setToolTip(QApplication::translate("Dialog", "Removes the directory specified by dirName.", Q_NULLPTR));
#endif // QT_NO_TOOLTIP
        pushButton_24->setText(QApplication::translate("Dialog", "rmdir()", Q_NULLPTR));
#ifndef QT_NO_TOOLTIP
        pushButton_12->setToolTip(QApplication::translate("Dialog", "Removes the directory, including all its contents.", Q_NULLPTR));
#endif // QT_NO_TOOLTIP
        pushButton_12->setText(QApplication::translate("Dialog", "removeRecursively()", Q_NULLPTR));
        groupBox_3->setTitle(QApplication::translate("Dialog", "\346\226\207\344\273\266\346\210\226\347\233\256\345\275\225\344\277\241\346\201\257", Q_NULLPTR));
#ifndef QT_NO_TOOLTIP
        pushButton_14->setToolTip(QApplication::translate("Dialog", "Returns the absolute path (a path that starts with \"/\" or with a drive specification)", Q_NULLPTR));
#endif // QT_NO_TOOLTIP
        pushButton_14->setText(QApplication::translate("Dialog", "absolutePath()", Q_NULLPTR));
#ifndef QT_NO_TOOLTIP
        pushButton_15->setToolTip(QApplication::translate("Dialog", "Returns the canonical path, i.e. a path without symbolic links or redundant \".\" or \"..\" elements.", Q_NULLPTR));
#endif // QT_NO_TOOLTIP
        pushButton_15->setText(QApplication::translate("Dialog", "canonicalPath()", Q_NULLPTR));
#ifndef QT_NO_TOOLTIP
        pushButton_19->setToolTip(QApplication::translate("Dialog", "Returns the path name of a file in the directory", Q_NULLPTR));
#endif // QT_NO_TOOLTIP
        pushButton_19->setText(QApplication::translate("Dialog", "filePath()", Q_NULLPTR));
#ifndef QT_NO_TOOLTIP
        pushButton_16->setToolTip(QApplication::translate("Dialog", "Returns the name of the directory", Q_NULLPTR));
#endif // QT_NO_TOOLTIP
        pushButton_16->setText(QApplication::translate("Dialog", "dirName()", Q_NULLPTR));
#ifndef QT_NO_TOOLTIP
        pushButton_18->setToolTip(QApplication::translate("Dialog", "Returns true if the directory exists", Q_NULLPTR));
#endif // QT_NO_TOOLTIP
        pushButton_18->setText(QApplication::translate("Dialog", "exists()", Q_NULLPTR));
#ifndef QT_NO_TOOLTIP
        pushButton_13->setToolTip(QApplication::translate("Dialog", "Returns the absolute path name of a file in the directory", Q_NULLPTR));
#endif // QT_NO_TOOLTIP
        pushButton_13->setText(QApplication::translate("Dialog", "absoluteFilePath()", Q_NULLPTR));
#ifndef QT_NO_TOOLTIP
        pushButton_17->setToolTip(QApplication::translate("Dialog", "Returns a list of the names of all the files and directories in the directory", Q_NULLPTR));
#endif // QT_NO_TOOLTIP
        pushButton_17->setText(QApplication::translate("Dialog", "entryList(file)", Q_NULLPTR));
#ifndef QT_NO_TOOLTIP
        pushButton_11->setToolTip(QApplication::translate("Dialog", "Returns a list of the names of all the files and directories in the directory", Q_NULLPTR));
#endif // QT_NO_TOOLTIP
        pushButton_11->setText(QApplication::translate("Dialog", "entryList(dir)", Q_NULLPTR));
        toolBox->setItemText(toolBox->indexOf(pageDir), QApplication::translate("Dialog", "QDir\347\261\273", Q_NULLPTR));
        groupBox_5->setTitle(QString());
#ifndef QT_NO_TOOLTIP
        pushButton_21->setToolTip(QApplication::translate("Dialog", "Constructs a QTemporaryDir using as template the application name ", Q_NULLPTR));
#endif // QT_NO_TOOLTIP
        pushButton_21->setText(QApplication::translate("Dialog", "\346\226\260\345\273\272\344\270\264\346\227\266\346\226\207\344\273\266\345\244\271", Q_NULLPTR));
#ifndef QT_NO_TOOLTIP
        pushButton_25->setToolTip(QApplication::translate("Dialog", "QTemporaryFile is used to create unique temporary files safely", Q_NULLPTR));
#endif // QT_NO_TOOLTIP
        pushButton_25->setText(QApplication::translate("Dialog", "\346\226\260\345\273\272\344\270\264\346\227\266\346\226\207\344\273\266", Q_NULLPTR));
        toolBox->setItemText(toolBox->indexOf(pageTemp), QApplication::translate("Dialog", "QTemporaryDir\345\222\214QTemporaryFile", Q_NULLPTR));
        groupBox_11->setTitle(QString());
#ifndef QT_NO_TOOLTIP
        pushButton_46->setToolTip(QApplication::translate("Dialog", "Adds path to the file system watcher if path exists.", Q_NULLPTR));
#endif // QT_NO_TOOLTIP
        pushButton_46->setText(QApplication::translate("Dialog", "addPath()\345\274\200\345\247\213\347\233\221\345\220\254", Q_NULLPTR));
#ifndef QT_NO_TOOLTIP
        pushButton_47->setToolTip(QApplication::translate("Dialog", "Removes the specified path from the file system watcher.", Q_NULLPTR));
#endif // QT_NO_TOOLTIP
        pushButton_47->setText(QApplication::translate("Dialog", "removePath()\345\201\234\346\255\242\347\233\221\345\220\254", Q_NULLPTR));
#ifndef QT_NO_TOOLTIP
        pushButton_52->setToolTip(QApplication::translate("Dialog", "Returns a list of paths to directories that are being watched.", Q_NULLPTR));
#endif // QT_NO_TOOLTIP
        pushButton_52->setText(QApplication::translate("Dialog", "directories()", Q_NULLPTR));
#ifndef QT_NO_TOOLTIP
        pushButton_57->setToolTip(QApplication::translate("Dialog", "Returns a list of paths to files that are being watched.", Q_NULLPTR));
#endif // QT_NO_TOOLTIP
        pushButton_57->setText(QApplication::translate("Dialog", "files()", Q_NULLPTR));
        toolBox->setItemText(toolBox->indexOf(pageWatcher), QApplication::translate("Dialog", "QFileSystemWatcher\347\261\273", Q_NULLPTR));
        groupBox_2->setTitle(QString());
        groupBox_7->setTitle(QString());
        pushButton_41->setText(QApplication::translate("Dialog", "\346\211\223\345\274\200\346\226\207\344\273\266", Q_NULLPTR));
        pushButton_45->setText(QApplication::translate("Dialog", "\346\211\223\345\274\200\347\233\256\345\275\225", Q_NULLPTR));
        pushButton_5->setText(QApplication::translate("Dialog", "\346\270\205\351\231\244\346\226\207\346\234\254\346\241\206", Q_NULLPTR));
        label->setText(QApplication::translate("Dialog", "\346\226\207 \344\273\266 ", Q_NULLPTR));
        label_2->setText(QApplication::translate("Dialog", "\347\233\256 \345\275\225 ", Q_NULLPTR));
        label_3->setText(QApplication::translate("Dialog", "\344\277\241 \346\201\257 ", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class Dialog: public Ui_Dialog {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_DIALOG_H
